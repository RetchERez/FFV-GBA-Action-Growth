FINAL FANTASY V ADVANCE: ACTION GROWTH
Version 1.3

By RetchERezzed
Inspired by demgelphoenix

================================================================
WHAT THIS DOES
================================================================

Action Growth replaces traditional character EXP leveling with permanent use-based progression inspired by Final Fantasy II.

Final Fantasy V's Job system remains active. Jobs still determine abilities, equipment, and playstyle, but permanent character growth now comes from what each character does in battle.

Characters can develop:

* HP
* MP
* Strength
* Agility
* Stamina
* Magic
* Attack
* Defense
* Evasion
* Magic Defense
* Combat Rank

Combat Rank supplies the Level-like value that Final Fantasy V Advance still needs for Level-sensitive battle formulas.

Traditional character EXP leveling is disabled. Automatic victory ABP is disabled. Current Job AP comes from current-Job-native actions.

Growth is chance-based. A qualifying action gives a chance to grow, not a guaranteed increase every time.

================================================================
VERSION 1.3 SUMMARY
================================================================

Version 1.3 is the battle-exit safety release.

It keeps Version 1.2's Action Growth balance and Job AP pacing intact, then adds one defensive guard to the custom post-battle notification return path. This is intended to prevent alternate battle exits from remaining stuck on the battle screen after the battle should return to the field, map, or story event.

This release replaces Version 1.2 and all v1.2.1 BattleExitGuard test builds.

================================================================
CHANGELOG
================================================================

Version 1.3

* Adds a defensive battle-exit guard to the Action Growth post-battle notification return path
* Targets the reported non-transition issue affecting L/R escape, the !Flee command, and scripted battle exits such as Galuf vs. Exdeath
* Marks the active result record complete before returning to native code when no Action Growth message is pending
* Preserves the existing helper at 0x70E3C0 from the TEST1 audit correction
* Places the new helper at verified unused free space beginning at 0x70E3C4
* Keeps Version 1.2's growth balance unchanged
* Keeps Version 1.2's Job AP scaling unchanged
* Keeps Version 1.2's stat persistence unchanged
* Keeps normal victory growth messages working
* Keeps the package patch-only with TXT documentation only

Version 1.2

* Combines the Version 1.1 stat-persistence fixes and Job AP improvements into one public release
* Fixes Strength, Agility, Stamina, and Magic growth being lost after Job changes
* Keeps earned core-stat growth persistent when the game rebuilds Job and stat values
* Updates Combat Rank so it uses Action Growth progress instead of temporary working stats
* Keeps Attack, Defense, Evasion, and Magic Defense persistence intact
* Restores safe post-battle growth-message timing
* Fixes the reward-screen freeze caused by the broken late post-battle message path
* Adds Battle Rank scaling for Job AP so tougher battles can be more rewarding
* Keeps low-level battles from inflating early Job AP too much
* Adds limited normal Attack AP for Chemist, Beastmaster, Oracle, Cannoneer, and Samurai
* Makes Berserker auto-attacks count properly for Berserker Job AP
* Reduces Chemist grind pressure by allowing limited Attack AP instead of requiring repeated Drink use
* Reduces progression drag for Beastmaster and Oracle during normal story play
* Keeps native Job commands as the best way to master each Job
* Smooths global growth odds so early-game and midgame dry streaks are reduced
* Extends the full-rate high-stat band to 0 through 75
* Smooths low-Rank Combat Rank thresholds so active party members are less likely to remain far behind during normal early play
* Keeps Rank 4 and higher pacing from the previous final build unchanged
* Keeps the release package patch-only with TXT documentation only

Version 1.1

* Fixed the Version 1.0 core-stat persistence bug
* Made Strength, Agility, Stamina, and Magic growth survive Job and stat recalculation
* Updated Combat Rank persistence so it no longer depends on temporary working stats
* Kept Attack, Defense, Evasion, and Magic Defense persistence intact
* Kept the corrected Version 1.0 post-battle growth notification concept

Version 1.0

* Initial public Action Growth release
* Replaced traditional character EXP progression with permanent use-based character growth
* Added permanent growth for HP, MP, Strength, Agility, Stamina, Magic, Attack, Defense, Evasion, and Magic Defense
* Added Combat Rank as the Level-like value used by Level-sensitive battle formulas
* Disabled automatic victory ABP
* Awarded current Job AP from current-Job-native actions instead of automatic battle victory rewards
* Added high-stat taper and battle-saturation logic to reduce repetitive abuse
* Kept Final Fantasy V's Job system, abilities, equipment, maps, items, enemy AI, and story progression intact
* Added corrected post-battle growth notifications for stat and Rank increases

================================================================
PLAYER NOTES
================================================================

A new game is recommended for the cleanest full-progression curve.

Existing saves may load, but old growth that was already erased by Version 1.0 cannot be reconstructed with certainty.

Bartz may naturally stay ahead early because he starts fighting before the rest of the party. Later party members should still catch up more smoothly than before.

Not every battle will show a growth message. Growth is still random, but Version 1.2 and later reduce long dry streaks.

Permanent growth messages can appear during the normal battle-results sequence, including increases to:

* STR
* AGI
* STA
* MAG
* HP
* MP
* ATK
* DEF
* EVA
* MDEF
* Combat Rank

================================================================
WHAT REMAINS INTACT
================================================================

The hack focuses on character progression. The following remain fundamentally intact:

* Jobs and Job equipment rules
* Learned abilities
* Spell lists
* Blue Magic learning
* Enemy AI
* Story progression
* Maps and events
* Shops
* Items and equipment
* Enemy formations
* Standard save-file format

================================================================
VERSION 1.3 TECHNICAL NOTES
================================================================

Version 1.3 keeps the Version 1.2 Final binary intact except for the battle-exit guard.

Changes from Version 1.2 Final:

0x70DF9A
F0 BC -> 13 E2

0x70E3C4-0x70E3D1
FF FF FF FF FF FF FF FF FF FF FF FF FF FF
->
FF 2E 01 D9 63 20 B0 70 F0 BC 01 BC 00 47

The helper at 0x70E3C0 remains unchanged as:

01 20 70 47

================================================================
VALIDATION
================================================================

Static package validation
PASS

IPS application from clean USA ROM
PASS

GBA header/logo preservation
PASS

Version 1.3 battle-exit guard free-space audit
PASS

mGBA 0.10.5 boot test
PASS

mGBA 0.10.5 save-load test using a SharkPort-derived save
PASS

mGBA 0.10.5 forced valid battle test from The Rift, Last Floor
PASS

mGBA 0.10.5 L/R escape return-to-field test
PASS

mGBA 0.10.5 normal victory return-to-field test with Action Growth messages
PASS

Direct !Flee and Galuf vs. Exdeath script tests were not independently reproduced in the build runtime. Version 1.3 targets the shared battle-result completion path that also covers those reported symptoms.

================================================================
INSTALLATION
================================================================

Required base ROM
Final Fantasy V Advance (USA)

Required clean ROM size
8,388,608 bytes

Required clean ROM CRC32
7A24AB0C

Required clean ROM SHA-256
55c5f8222759b556c562fc6f72f54ac01128e077e3dde25035be1158ff704374

Patch file
FFV_GBA_Action_Growth_v13.ips

Expected patched ROM CRC32
6319486E

Expected patched ROM SHA-256
90508d10d192191741c362655943e5cc9c07c4cba6d726b16eaa0ed115fa0544

IPS SHA-256
fc88f57c8edd4e9433da733771cb0948628bbb1f2adf52e264f944e8d6e5fd6a

Apply the IPS patch with a standard IPS-compatible patcher.

A new game is recommended for the cleanest full-progression curve.

No commercial ROM is included with this patch.

================================================================
CREDITS
================================================================

Action Growth was planned, developed, balanced, and tested by RetchERezzed.

Special thanks to demgelphoenix, whose idea served as the inspiration for the Action Growth concept.

================================================================
QUOTE
================================================================

"Creating that which hasn't been created before will always be the cause of envy."
