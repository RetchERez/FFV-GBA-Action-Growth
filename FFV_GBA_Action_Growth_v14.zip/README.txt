FINAL FANTASY V ADVANCE: ACTION GROWTH
Version 1.4 — Rank corruption fix

By RetchERezzed
Inspired by demgelphoenix

WHAT CHANGED IN 1.4
Fixes a demonstrated v1.3 battle-result error that could force Combat Rank 99
without earned growth. The notification-return helper incorrectly wrote 99 to
the live actor's Rank. Version 1.4 removes exactly that four-byte write sequence.
The surrounding return layout and all other v1.3 bytes are preserved, including
balance, growth odds, Job AP curves, abilities, enemy AI, maps and save format.

WHAT THIS DOES
Action Growth replaces traditional character EXP leveling with permanent use-based progression inspired by Final Fantasy II.

Final Fantasy V's Job system remains active. Jobs still determine abilities, equipment, and playstyle, but permanent character growth now comes from what each character does in battle.

Characters can develop:

* HP
* MP
* Strength
* Agility
* Stamina
* Magic
* Attack
* Defense
* Evasion
* Magic Defense
* Combat Rank

Combat Rank supplies the Level-like value that Final Fantasy V Advance still needs for Level-sensitive battle formulas.

Traditional character EXP leveling is disabled. Automatic victory ABP is disabled. Current Job AP comes from current-Job-native actions.

Growth is chance-based. A qualifying action gives a chance to grow, not a guaranteed increase every time.

VERIFIED TESTS
Real headless mGBA 0.10.5: the same victory produces Rank99 on public v1.3 and
retains Rank3 on v1.4. Genuine first Job award: all four members retain their
Ranks/counters/stats/maxima on both versions. Twenty Job cycles for Bartz and
a sequence for each other accessible member show no accumulation. Natural
STR/AGI/STA/MAG gains survive native Job changes; HP/MP recompute correctly.
Five native SRAM save/fresh-core load rounds retain the complete tested state.
Faris's actual departure/rejoin, native Rank+1 text, a zero-growth result, and
Wing Raptor's story continuation pass. Native !Flee and a separate L/R escape both return to the field.

TEST LIMITS
24/25 matrix cases PASS with stated scope; 1 BLOCKED.
Galuf versus Exdeath has not been independently verified: no validated pre-event GBA save was available. This remains R22 BLOCKED; every story exit is not certified.
No claim of universal save compatibility or 100% bug-free gameplay is made.
The August first-Job Rank12-13 spike was not reproduced on current v1.3's award;
the new Rank99 fix addresses a separate instruction-traced defect.

EXISTING SAVES
Back up your save. This prevents the demonstrated future Rank99 write; it does
not reconstruct erased growth or promise to repair already inflated HP.
Known v1.1 counters survived the tested native import and repeated saves.
Version 1.0 did not store permanent core gains reliably: absent counters become
zero earned growth. A Job rebuild can lower old inflated Rank, HP and MP
(tested example: Rank14 -> 1, max HP320 -> 35, max MP76 -> 3).
Import fixtures were genuine prior-ROM native saves created from a documented
v1.4-origin checkpoint, not untouched historical playthroughs.

PLAYER NOTES
A new game is recommended for the cleanest full-progression curve.

Existing saves may load, but old growth that was already erased by Version 1.0 cannot be reconstructed with certainty.

Bartz may naturally stay ahead early because he starts fighting before the rest of the party. Later party members should still catch up more smoothly than before.

Not every battle will show a growth message. Growth is still random, but Version 1.2 and later reduce long dry streaks.

Permanent growth messages can appear during the normal battle-results sequence, including increases to:

* STR
* AGI
* STA
* MAG
* HP
* MP
* ATK
* DEF
* EVA
* MDEF
* Combat Rank

INSTALLATION
Apply FFV_GBA_Action_Growth_v14.ips to a clean Final Fantasy V Advance USA ROM
with an IPS-compatible patcher. Do not patch an already modified ROM.

Clean size: 8,388,608 bytes
Clean CRC32: 7A24AB0C
Clean SHA-256:
55c5f8222759b556c562fc6f72f54ac01128e077e3dde25035be1158ff704374

Patched CRC32: 58AAADE0
Patched SHA-256:
fee951bd8b5f0a0e0e3e43054a7a135ec009e396deb97562c459f39bb2527856
IPS size: 311,984 bytes
IPS SHA-256:
98ddbb5e113503a51d3268950cdf7e50c3a7f67ac65574412bc8cca235c2a944

PACKAGE CONTENTS
FFV_GBA_Action_Growth_v14.ips
README.txt
No commercial ROM or save file is included in this public ZIP.
