FINAL FANTASY V ADVANCE: ACTION GROWTH
Version 1.1

By RetchERezzed
Inspired by demgelphoenix

================================================================
WHAT THIS DOES
================================================================

Action Growth replaces traditional character EXP leveling with permanent use-based progression inspired by Final Fantasy II.

Final Fantasy V's Job system remains active. Jobs still determine abilities, equipment, and playstyle, but permanent character growth now comes from what each character does in battle.

Characters can develop:

* HP
* MP
* Strength
* Agility
* Stamina
* Magic
* Attack
* Defense
* Evasion
* Magic Defense
* Combat Rank

Combat Rank supplies the Level-like value that Final Fantasy V Advance still needs for Level-sensitive battle formulas.

Traditional character EXP leveling is disabled. Automatic victory ABP is disabled. Current Job AP comes from current-Job-native actions.

================================================================
CHANGELOG
================================================================

Version 1.0

* Initial public Action Growth release
* Replaces traditional character EXP progression with permanent use-based character growth
* Adds permanent growth for HP, MP, Strength, Agility, Stamina, Magic, Attack, Defense, Evasion, and Magic Defense
* Adds Combat Rank as the Level-like value used by Level-sensitive battle formulas
* Disables automatic victory ABP
* Awards current Job AP from current-Job-native actions instead of automatic battle victory rewards
* Adds high-stat taper and battle-saturation logic to reduce repetitive abuse
* Keeps Final Fantasy V's Job system, abilities, equipment, maps, items, enemy AI, and story progression intact
* Adds corrected post-battle growth notifications for stat and Rank increases

Version 1.1

* Fixes the version 1.0 core-stat persistence bug
* Stores Strength, Agility, Stamina, and Magic growth in persistent Action Growth counters at +0x04 through +0x07 with schema bits
* Reapplies stored core growth after Final Fantasy V Advance rebuilds native Job/stat values
* Updates Combat Rank persistence so it uses Action Growth values instead of recalculable native working stats
* Keeps Attack, Defense, Evasion, and Magic Defense persistence at +0x54 through +0x57
* Moves temporary post-battle notification scratch state to +0x60 through +0x63
* Restores safe version 1.0-style post-battle growth-message timing
* Removes the broken late version 1.1 post-battle dispatcher path that caused reward-screen freezes
* Smooths global growth odds so early-game and midgame dry streaks are reduced
* Extends the full-rate high-stat band to 0 through 75
* Smooths low-Rank Combat Rank thresholds so active party members are less likely to remain far behind during normal early play
* Keeps Rank 4 and higher pacing from the previous final build unchanged
* Keeps the release package patch-only with TXT documentation only

================================================================
VERSION 1.1 FINAL FIXES
================================================================

Version 1.1 fixes the version 1.0 core-stat persistence bug.

Strength, Agility, Stamina, and Magic growth are now stored in persistent Action Growth counters at +0x04 through +0x07 with schema bits.

After Final Fantasy V Advance rebuilds native Job/stat values, Action Growth reapplies the stored core growth and caps the result at 99.

This means Job changes should no longer erase new STR, AGI, STA, or MAG growth.

Version 1.1 also restores the safer version 1.0-style post-battle growth-message timing, but redirects temporary notification scratch state to +0x60 through +0x63.

The broken late version 1.1 post-battle dispatcher hook is not used.

================================================================
BALANCE NOTES
================================================================

Version 1.1 keeps Action Growth probability-based. A stat is not expected to increase after every action or every battle.

The final balance pass smooths ordinary growth odds globally and reduces early Combat Rank spread. Bartz can still be ahead because he starts fighting earlier, but active party members should be less likely to remain several Ranks behind during normal attack-heavy play.

Low Combat Rank thresholds are smoother in this release:

* Rank 2 begins earlier than before
* Rank 3 begins earlier than before
* Rank 4 and higher pacing is unchanged from the previous final build

This is intended to reduce cases where one active character appears abandoned by the system while the rest of the party advances.

================================================================
INSTALLATION
================================================================

Required base ROM
Final Fantasy V Advance (USA)

Required clean ROM size
8,388,608 bytes

Required clean ROM CRC32
7A24AB0C

Patch file
FFV_GBA_Action_Growth_v11.ips

Expected patched ROM CRC32
EEB22D5A

Apply the IPS patch with a standard IPS-compatible patcher.

A new game is recommended for the cleanest full-progression curve.

================================================================
ENJOY
================================================================

"Creating that which hasn't been created before will always be a cause of envy."
