FINAL FANTASY V ADVANCE: ACTION GROWTH
Version 1.0

By RetchERezzed
Planned and Tested by RetchERezzed
Inspired by: demgelphoenix

Release naming update: the final patch/package are named FFV_GBA_Action_Growth_v10. The underlying tested RC2 notification code is unchanged.

================================================================
OVERVIEW
================================================================

Action Growth replaces Final Fantasy V Advance's traditional character EXP leveling with a permanent use-based progression system inspired by Final Fantasy II. Final Fantasy V's Job system remains intact, but characters no longer become stronger simply because they accumulated enough EXP. Instead, permanent development follows what each character actually does in battle. Physical offense develops physical ability, magic use develops magical ability, taking and blocking attacks develops durability and defense, hostile magic develops Magic Defense, and being attacked or successfully dodging develops Evasion. Losing HP can improve Max HP, spending MP can improve Max MP, and actions native to the current Job develop that Job.

The goal is to preserve what makes Final Fantasy V unique while giving every character a more personal progression history. A mage can become physically capable by fighting physically, a warrior can become magically capable by actually using magic, and two characters who have fought the same number of battles can still develop very differently.

Final Fantasy II does not use the usual system where characters gain a conventional overall Level from EXP and receive a package of stat increases. Instead, much of the character's development happens individually through use. Physical combat develops physical capability, magic use develops magical capability, taking damage can improve survivability, spending MP can improve MP capacity, weapon skills improve through using those weapon types, and individual spells can improve through repeated use. Action Growth adapts that philosophy without copying every FFII formula or adding separate persistent weapon-category and individual spell levels.

================================================================
VICTORY GROWTH NOTIFICATIONS - FIXED RC2
================================================================

Version 1.0 includes the corrected victory-result notification system while preserving the established Action Growth gameplay rules.

When permanent growth occurs, the normal battle-results sequence can report:

<name> STR increased!
<name> AGI increased!
<name> STA increased!
<name> MAG increased!
<name> HP increased!
<name> MP increased!
<name> ATK increased!
<name> DEF increased!
<name> EVA increased!
<name> MDEF increased!
<name> Rank increased!

The <name> prefix is resolved from Final Fantasy V Advance's live character-name
buffer. It is not hard-coded to Bartz, Lenna, Galuf, Faris, or Krile. Renamed
characters therefore use the current in-game name.

The original notification implementation is superseded. Two independent defects
were removed: a notification reset store that could overwrite Current HP, and a
text-dispatch design that could execute FFVA's dynamic-name control outside its
native TEXT environment and corrupt battle graphics. RC2 keeps the native text
control environment by using a complete relocated copy of the native TEXT archive
for only the eleven new result IDs. The original native TEXT archive is untouched.

RC2 also replaces the earlier one-byte battle marker with a full 16-bit battle
epoch plus signature. Stale notification bits from an earlier battle are rejected
even when the low byte of the battle counter wraps after 256 battles. The scratch
bytes are cleared after victory processing and are never stored in the persistent
ATK/DEF/EVA/MDEF proficiency area at +0x54..+0x57.

The notification branch was tested against the same real battle state used during
the regression investigation. Its battle frames before, during, and after a real
action were pixel-identical to the exact pre-notification build. All eleven
notification messages were rendered in the native result window, a real stat
growth event was detected and reported, and the result flow returned normally.

================================================================
WHAT CHANGED IN RC2 AND WHY
================================================================

RC2 keeps the established Action Growth rules and adds the requested growth
notifications without changing how characters earn growth. The notification work
was rebuilt because the first notification implementation introduced two real
runtime hazards that did not exist in the pre-notification build.

Changes in RC2:

* Victory growth messages were restored for STR, AGI, STA, MAG, HP, MP, ATK, DEF,
  EVA, MDEF, and Combat Rank
* Character names are taken from FFV Advance's live character-name data so renamed
  characters and every normal party member use the correct name
* The earlier notification reset write that could overwrite Current HP was removed
* The earlier small custom text environment was replaced because FFV Advance's
  dynamic name control expects the native TEXT environment and could corrupt battle
  graphics when that context was missing
* RC2 uses a complete relocated copy of the native TEXT archive only for the eleven
  new result messages, leaving the game's original TEXT archive untouched
* Temporary notification state is kept separate from permanent ATK, DEF, EVA, and
  MDEF proficiency storage so displaying a message cannot erase character growth
* A 16-bit battle epoch plus signature replaces the earlier one-byte battle marker
  so stale result flags cannot reappear when the low battle-counter byte wraps after
  256 battles
* Notification scratch is cleared after victory-result processing so one battle's
  messages cannot leak into another battle
* The normal FFV result sequence is preserved, including victory, gil, treasure,
  growth messages, and return to gameplay
* Battle rendering was compared directly against the pre-notification build at the
  same checkpoints and matched pixel-for-pixel in the targeted regression test

These changes exist only to make the notification feature safe and native-looking.
They do not increase growth rates, change the ten training routes, alter Job AP
rules, or change Combat Rank balance.

================================================================
STATUS MENU TEXT
================================================================

Action Growth changes the meaning of several fields on FFV Advance's Status screen.
The three replacement/status labels shown in the current build are:

EXP unused: 0
EXP system off: 0
Abilities learned: <number>

They mean the following.

EXP unused: 0
Traditional character EXP is no longer the progression system. Character growth is
earned through Action Growth instead, and Combat Rank replaces the Level-like value
needed by FFV's battle formulas. The old Current EXP display therefore has no useful
progression meaning and is deliberately shown as 0. This is not missing EXP and is
not an error.

EXP system off: 0
This replaces the old Next EXP display. Because ordinary EXP-based level promotion
is disabled, there is no next EXP threshold to reach. The field is deliberately
shown as 0 to make it clear that the old EXP ladder is inactive rather than leaving
a misleading vanilla number on the screen.

Abilities learned: <number>
This is still a real FFV value. It is the count of Job abilities the character has
learned through Final Fantasy V's normal Job-learning system. Action Growth removes
automatic victory ABP, but it does not remove Jobs or learned abilities. Current Job
AP is earned by genuinely executing commands native to the current Job, and FFV's
normal Job thresholds still determine when abilities are learned. This line is not
EXP, AP, ABP, or a permanent Action Growth stat.

The same Status screen also shows RK instead of LV. RK means Combat Rank. It is the
Level-like number supplied to FFV's Level-sensitive battle formulas after normal
character EXP leveling is removed.

In short:

EXP unused       old Current EXP display, intentionally inactive
EXP system off   old Next EXP display, intentionally inactive
Abilities learned real FFV learned-ability count, still active
RK               Combat Rank, the replacement Level-like value

================================================================
CORE SYSTEM
================================================================

Value          Primary Training Route
----------------------------------------------------------------
HP             Lose HP from legitimate hostile damage
MP             Spend MP in battle
Strength       Deal positive physical damage
Agility        Complete actions, use dexterity skills, dodge
Stamina        Take or block hostile physical attacks
Magic          Execute genuine magic actions
Attack         Practice physical offense and connect with attacks
Defense        Defend, take, block, mitigate, Guard, Cover
Evasion        Be attacked for small practice, dodge for strongest growth
Magic Defense  Endure or resist hostile magic

HP grows from legitimate hostile HP loss. Physical and magical damage can both count, and any positive amount of hostile HP loss is valid training. Successful HP growth increases Max HP by the character's current permanent Stamina, up to 9999. MP grows from MP actually spent in battle, whether or not the spell succeeds, and successful MP growth increases Max MP by one quarter of current permanent Magic, rounded up, up to 999.

Strength grows from positive physical damage. Agility grows from completed physical and magical actions, with stronger opportunities from dexterity-oriented actions such as Steal, Mug theft, Throw, and actual dodges. Stamina grows from taking or blocking hostile physical attacks. Magic grows whenever a genuine magic action executes, even if the target resists it or the spell has no useful effect.

Attack grows from physical practice and successful connections, including 0-damage connections. Defense grows from Defend, physical hits, mitigation, Guard, blocks, and Cover. Evasion receives small practice from being genuinely hit or affected by hostile attacks and its strongest growth from actual physical dodges. Magic Defense grows when hostile magic genuinely resolves against the character, including resisted hostile spells.

================================================================
COMBAT RANK
================================================================

Combat Rank replaces the Level-like value that Final Fantasy V still needs for battle formulas. Rank ranges from 1 to 99 and summarizes permanent development across Strength, Agility, Stamina, Magic, Attack, Defense, Evasion, and Magic Defense.

Development Track   Rank Weight
----------------------------------------------------------------
Strength            x2
Agility             x2
Stamina             x2
Magic               x2
Attack              x1
Defense             x1
Evasion             x1
Magic Defense       x1
HP                  Not included
MP                  Not included

The four native FFV attributes count twice as heavily as the four Action Growth proficiencies. Native attributes are measured from each character's permanent starting baseline toward 99, while Attack, Defense, Evasion, and Magic Defense are measured from 0 toward 99. The final calibrated curve was chosen because a simple linear average made normal endgame Rank too low.

Rank 99 requires all eight 0-99 development values to be 99. If even one of those values is still 98, Combat Rank remains below 99. HP and MP are not included in Rank because they use different scales and already interact with Stamina and Magic.

Character   STR   AGI   STA   MAG
----------------------------------------------------------------
Bartz        28    25    27    25
Lenna        25    26    25    28
Galuf        27    24    28    24
Faris        27    27    26    26
Krile        25    28    24    27

Job bonuses, equipment bonuses, and temporary effective-stat changes do not count as permanent Action Growth for Rank.

================================================================
RANDOMIZATION AND STAT GROWTH
================================================================

Permanent stat gains are intentionally somewhat randomized. A qualifying action or battle result does not guarantee an increase. Instead, it creates a growth opportunity for the specific stat or resource that the action actually trained. The action determines WHAT can grow; probability determines WHETHER that eligible growth opportunity succeeds.

This means two characters can perform the same qualifying action and see different immediate results, or the same character can repeat an action across several battles without gaining a stat every time. That is expected behavior, not a missed trigger. The system is designed so repeated use produces a long-term tendency toward the abilities the character actually practices rather than a guaranteed increase on every action.

The probability depends on the strength of the evidence. Small practice starts at 2 / 256, a successful medium opportunity at 10 / 256, and full evidence at 12 / 256. HP and MP use their own resource-pressure chances based on how much HP was legitimately lost or how much MP was actually spent. As a permanent 0-99 value gets higher, its growth rate is reduced, and repeated evidence calls within the same battle also receive diminishing returns. Every uncapped 0-99 development value still retains a nonzero route to 99.

The randomness does not randomly choose an unrelated stat. Physical damage can create Strength growth opportunities, genuine magic use can create Magic growth opportunities, hostile physical interaction can create Stamina or Defense opportunities, and so on according to the training rules in this README. Job AP is separate: when a qualifying current-Job-native command genuinely executes, that Job receives its defined +1 AP rather than using these permanent-stat probability tables.

================================================================
GROWTH CURVES
================================================================

Evidence Type                    Base Chance
----------------------------------------------------------------
Small player practice            2 / 256
Small hostile-hit Evasion        4 / 256
Successful medium practice      10 / 256
Full evidence                   12 / 256

Current Value    Relative Growth Rate
----------------------------------------------------------------
0-60             100%
61-70             75%
71-80             50%
81-90             25%
91-98             12.5%

Action Growth uses growth opportunities rather than guaranteed stat gains. The rates are intentionally modest so normal play creates steady long-term development without producing a permanent stat increase every battle. Every uncapped 0-99 development value keeps a nonzero route to 99.

HP and MP use resource pressure. The more of the character's maximum resource that is legitimately lost or spent, the stronger the growth opportunity.

Resource Used/Lost vs. Maximum   Base Chance
----------------------------------------------------------------
Greater than 0                    2 / 256
At least 1/8                      4 / 256
At least 1/4                      7 / 256
At least 1/2                     12 / 256

Enemy level does not affect Action Growth. Any legitimate enemy can train a character at any Combat Rank, so weak-enemy grinding remains valid throughout the game. To prevent one indefinitely prolonged encounter from being optimal, a single battle gradually receives diminishing returns.

Evidence Calls in One Battle     Growth Rate
----------------------------------------------------------------
1-24                             100%
25-48                             50%
49+                               25%

================================================================
HOW JOB AP WORKS IN FINAL FANTASY V
================================================================

Job AP and permanent stat growth are two separate rewards from the same battle system. When a real action actually executes, Action Growth first checks whether that action is native to the character's CURRENT Job. If it is, that current Job receives exactly +1 AP. Canceled selections do not count, enemy level does not matter, and the command does not have to hit or succeed once it has genuinely executed.

FFV's original Job-level thresholds and learned-ability processing are still used. Action Growth changes where the AP comes from, not the Job ladder itself. Instead of receiving automatic ABP just for winning a battle, the character develops the current Job by actually using that Job's native commands. The current-Job AP counter is capped at 999.

Only the CURRENT Job can receive AP. An off-Job ability can still train permanent stats, but it does not secretly give AP to the Job that originally owns that ability. For example, a Knight equipped with Black Magic can train permanent Magic, Agility, and MP by casting, but that cast gives no Knight AP and no Black Mage AP because the character is currently a Knight. The Knight gains Knight AP from Attack or Guard.

Freelancer is the exception. Freelancer has no separate Job AP mask or normal Job-level ability ladder, so Freelancer actions train permanent character stats but do not accumulate Freelancer AP. Mime gains Mime AP from actually using Mimic, and the copied action then trains the Mime's permanent stats according to what that copied action really does.

Generic Defend is also separate from Job AP. Defend can train permanent Defense, but it is not a native AP command for a specific Job.

================================================================
WHAT AN ACTION CAN TRAIN
================================================================

Action / Result                         Permanent Training
----------------------------------------------------------------
Physical action executes                Small Agility + small Attack practice
Physical attack connects                Additional Attack practice
Positive physical damage                Strength
Steal executes                          Small Agility
Successful Steal                        Additional dexterity Agility
Mug executes                            Small Agility + physical Attack practice
Mug connects / deals damage             Attack / Strength as appropriate
Successful Mug theft                    Additional dexterity Agility
Throw executes                          Small + stronger dexterity Agility
Throw deals positive damage             Strength
Genuine magic executes                  Magic + small Agility
Positive MP actually spent              Max MP resource-pressure training
Defend selected                         Small Defense
Hostile physical hit                    Defense + small Evasion
Hostile physical damage                 Stamina + Max HP pressure
Physical block                          Stamina + Defense
Physical dodge                          Strong Agility + strong Evasion
Hostile magic resolves                  Magic Defense
Hostile magic hits / affects            Magic Defense + small Evasion
Hostile magic deals HP damage            Magic Defense + Evasion + HP pressure

The physical command family implemented by v1.0 is Attack, Kick, Focus, Jump, Lance, Mineuchi, Aim, Rapid Fire, and Bladeblitz. These use the physical rules above. Throw has its own dexterity route, while Steal and Mug have their own success-sensitive Agility routes.

The magic family implemented by v1.0 is Spellblade Lv1-Lv6, White Magic Lv1-Lv6, Black Magic Lv1-Lv6, Time Magic Lv1-Lv6, Summon Lv1-Lv5, Red Magic Lv1-Lv3, Dualcast, Blue Magic, Dark Arts Lv1-Lv5, and Call. Genuine execution trains Magic and small Agility. Positive MP expenditure trains Max MP; Call is the important exception because it costs no MP.

Some FFV utility and special commands are intentionally Job-AP-only in v1.0. They still develop the current Job when native to it, but the command itself does not directly roll a permanent stat. This avoids pretending that every utility command has an obvious physical or magical stat equivalent. The character can still gain permanent defensive development from enemy actions during the same battle.

================================================================
JOB-BY-JOB GUIDE
================================================================

Legend:
PHYS = small AGI/ATK practice; connection adds ATK; positive damage can add STR
MAG  = Magic + small AGI; positive MP spent can train Max MP
DEX  = Agility-focused action; success may add the stronger dexterity bonus
AP   = gives +1 current-Job AP when the command genuinely executes
AP-only = gives Job AP but no direct selected-action permanent-stat roll

Job              Native AP Commands                 Direct Permanent Training
--------------------------------------------------------------------------------------------------------------------------------
Knight           Attack, Guard                      Attack = PHYS; Guard = defensive growth when it actually blocks/mitigates
Monk             Attack, Kick, Focus, Chakra        Attack/Kick/Focus = PHYS; Chakra = AP-only
Thief            Attack, Flee, Steal, Mug           Attack = PHYS; Steal = DEX; Mug = DEX + PHYS; Flee = AP-only
Dragoon          Attack, Jump, Lance                Attack/Jump/Lance = PHYS
Ninja            Attack, Smoke, Image, Throw        Attack = PHYS; Throw = DEX + STR on damage; Smoke/Image = AP-only
Samurai          Attack, Mineuchi, Zeninage,        Attack/Mineuchi = PHYS; Zeninage/Iainuki = AP-only
                 Iainuki
Berserker        Attack                             Attack = PHYS
Ranger           Attack, Animals, Aim, Rapid Fire   Attack/Aim/Rapid Fire = PHYS; Animals = AP-only
Mystic Knight    Attack, Spellblade Lv1-Lv6         Attack = PHYS; Spellblade cast = MAG; later weapon attacks = PHYS
White Mage       White Magic Lv1-Lv6                MAG
Black Mage       Black Magic Lv1-Lv6                MAG
Time Mage        Time Magic Lv1-Lv6                 MAG
Summoner         Call, Summon Lv1-Lv5               Call = MAG without MP growth; Summon = MAG
Blue Mage        Check, Scan, Blue Magic            Blue Magic = MAG; Check/Scan = AP-only
Red Mage         Red Magic Lv1-Lv3, Dualcast        MAG; Dualcast is protected from duplicate action-local growth
Beastmaster      Calm, Control, Catch, Release      AP-only
Chemist          Mix, Drink, Recover, Revive        AP-only
Geomancer        Gaia                               AP-only
Bard             Hide, Reveal, Sing                 AP-only
Dancer           Flirt, Dance                       AP-only
Necromancer      Dark Arts Lv1-Lv5, Oath           Dark Arts = MAG; Oath = AP-only
Oracle           Condemn, Predict                   AP-only
Cannoneer        Open Fire, Combine                 AP-only
Gladiator        Attack, Bladeblitz, Finisher       Attack/Bladeblitz = PHYS; Finisher = AP-only
Mime             Mimic                              Mimic = AP; copied action trains according to what actually executes
Freelancer       No separate Job AP                 Permanent stats still train normally from qualifying actions/results

================================================================
HOW THIS PLAYS IN PRACTICE
================================================================

A Knight who repeatedly uses Attack naturally develops toward a physical build because Attack can train Agility and Attack every time it genuinely executes, with stronger Attack training on a connection and Strength training when positive damage is dealt. Guard develops Knight AP when used, but the permanent Stamina and Defense gains come from actually being tested by the incoming physical attack.

A White Mage who casts White Magic develops White Mage AP and permanent Magic, Agility, and MP through genuine spell use. If that White Mage equips a physical command and starts fighting physically, the character can still develop Strength and Attack, but those off-Job physical actions do not advance White Mage AP.

A Thief provides the clearest example of the two systems working together. Flee can develop Thief AP without directly raising a permanent stat. Steal develops Thief AP plus Agility practice, and a successful theft adds the stronger dexterity Agility opportunity. Mug can develop Thief AP while also training Agility, Attack, and Strength depending on whether the theft succeeds, whether the physical portion connects, and whether it deals positive damage.

A Mystic Knight can develop both sides of the character naturally. Casting Spellblade develops Mystic Knight AP, Magic, Agility, and MP when MP is spent. Attacking with the enchanted weapon later follows the normal physical rules and can develop Attack, Strength, and Agility.

A Summoner can gain Summoner AP from either Call or Summon. Both count as genuine magical practice for Magic and Agility, but Call cannot train Max MP because no MP was actually spent. Normal Summon casts can train Max MP from their real MP expenditure.

A Mime gains Mime AP from Mimic itself. The copied action is then treated as the action the Mime actually performs for permanent growth. Mimicking a physical attack trains the Mime through physical rules; mimicking magic trains the Mime through magical rules.

A Freelancer receives no separate Freelancer AP, but permanent character development remains fully active. This is why a Freelancer can gain Rank, HP, MP, core stats, and proficiencies even though there is no Freelancer AP ladder to fill.


================================================================
COMPATIBILITY AND SAVES
================================================================

Action Growth changes character progression rather than FFV's general content. Jobs, Job equipment rules, Job ability lists, native Job-level thresholds, learned-ability processing, spell lists, Blue Magic Learning, monster Levels, enemy battle AI, story progression, maps, events, shops, items, equipment, enemy formations, and the standard 32 KiB save-file format remain fundamentally intact.

Combat Rank intentionally occupies the Level-like role used by FFV battle formulas for party characters. Level-sensitive effects therefore still work, but player-side Level checks now use Combat Rank. Monsters continue using their normal FFV monster Levels.

Existing saves receive one-time Action Growth initialization while preserving native character data such as Jobs, equipment, abilities, inventory, HP/MP, and story progress. A new game is strongly recommended for the intended complete progression curve, and existing saves should always be backed up before changing ROM-hack versions.

Compatibility with other ROM hacks is not guaranteed because Action Growth modifies battle progression, result processing, Job AP, persistence, and Level-related behavior. For the safest installation, apply it directly to the exact clean USA ROM listed below.

================================================================
POSSIBLE GLITCHES AND BUG REPORTS
================================================================

Action Growth v1.0 has been tested against the targeted battle, progression, save, notification, and visual-regression cases documented with this release. However, not every possible combination of Jobs, abilities, enemies, battle states, save histories, emulator configurations, and long-play situations can be exhaustively tested. Unknown edge cases or glitches may therefore still exist.

If you encounter a reproducible problem, please report it. When possible, include the emulator and version being used, the Job and abilities involved, the enemy or battle where it happened, what action was performed, what you expected to happen, what actually happened, and clear steps that reproduce the issue. A normal save file or save state from shortly before the problem can also be useful when appropriate.

Please distinguish issues caused by Action Growth from problems produced by an incorrect base ROM, another ROM hack, cheats, emulator-specific behavior, or an unsupported patch combination. Reproducible reports are the most useful for identifying and correcting genuine Action Growth issues.

================================================================
CAPS
================================================================

Value           Cap
----------------------------------------------------------------
Strength         99
Agility          99
Stamina          99
Magic            99
Attack           99
Defense          99
Evasion          99
Magic Defense    99
Combat Rank      99
HP             9999
MP              999

================================================================
F.A.Q.
================================================================

Q: Why does a qualifying action sometimes raise a stat and sometimes not?
A: Permanent stat growth is probabilistic. A qualifying action or result creates an opportunity for the appropriate stat, but that opportunity still has to pass its growth chance. The chance depends on the evidence strength, the character's current permanent value, and same-battle diminishing returns. The action decides which stat is eligible; the random element decides whether that eligible opportunity succeeds.

Q: Can Combat Rank reach 99 before the character's permanent stats are maxed?
A: No. Rank 99 is reserved for complete mastery of Strength, Agility, Stamina, Magic, Attack, Defense, Evasion, and Magic Defense. All eight must be 99.

Q: Why are Strength, Agility, Stamina, and Magic weighted more heavily?
A: They are FFV's native core character attributes and are used broadly by the original battle system. Attack, Defense, Evasion, and Magic Defense are additional Action Growth proficiency tracks.

Q: Does the Library of the Ancients Level 5 Death setup still work?
A: Yes. Level 5 Death still checks whether the target's Level-like value is divisible by 5. For party characters, Combat Rank supplies that Level-like value, so Rank 5, 10, 15, 20, 25, 30, and so on can be affected and can use the normal Learning setup.

Q: What happens when the player casts Level 5 Death on monsters?
A: Monsters retain their normal FFV monster Levels, so player-cast Level 5 Death continues checking the monster's normal Level.

Q: What about other Level-based Blue Magic?
A: The same compatibility principle applies. Party-side Level-like checks use Combat Rank, while monsters continue using their normal monster Level.

Q: Can weak enemies still train a high-Rank character?
A: Yes. Enemy level never disables or reduces Action Growth.

Q: Does changing Jobs reset permanent stats or Combat Rank?
A: No. Permanent Action Growth belongs to the character.

Q: Can equipment or Job stat bonuses raise Combat Rank?
A: No. Combat Rank uses permanent development, not temporary effective-stat bonuses.

Q: Does a physical miss train anything?
A: It can provide small Attack and Agility practice, but it does not provide the connection bonus or Strength growth.

Q: Does a 0-damage physical hit count?
A: It counts as a physical connection for Attack and as a completed physical action for Agility, but not for Strength.

Q: Does resisted magic still train Magic?
A: Yes. If a genuine magic action executes, it represents Magic practice whether or not the target accepts the effect. Actual MP expenditure can also train Max MP.

Q: Does Cure on a full-HP target still train Magic?
A: Yes. The spell genuinely executed, so it can still train Magic and MP expenditure.

Q: Does hostile magic train Evasion and Magic Defense at the same time?
A: It can. Hostile magic resolving against the character trains Magic Defense, and an actual hit or effect can also provide a small Evasion exposure opportunity.

Q: Does Defend train Defense if nothing attacks the character?
A: Entering Defend provides only a small Defense opportunity. Actual incoming physical interaction provides stronger defensive training.

Q: Does Counter train just because it is equipped?
A: No. Counter must actually activate and dispatch its reaction attack.

Q: Does Cover train just because it is equipped?
A: No. Cover must actually redirect an incoming attack.

Q: Who gets Action Growth from Mimic?
A: The character performing Mimic. The copied action is classified when it actually executes.

Q: Does normal character EXP still matter?
A: No. Traditional character EXP leveling is disabled, and Combat Rank supplies the Level-like battle value instead.

Q: Does winning a battle still give normal ABP?
A: No. Automatic victory ABP is disabled. Current Job AP comes from actual current-Job-native actions.

Q: Are separate weapon levels or individual spell levels included?
A: No. Version 1.0 focuses on the ten permanent Action Growth values and FFV's existing Job system.

Q: Will you be making this a romhack for the Super Nintendo version of Final Fantasy V?
A: There is a lot of information out there, so I believe it is plausible. I will try.

================================================================
FINAL RELEASE FILE NAMES
================================================================

ZIP package
FFV_GBA_Action_Growth_v10.zip

IPS patch
FFV_GBA_Action_Growth_v10.ips

The v10 name means Version 1.0. The internal RC2 wording in the engineering notes
refers only to the corrected notification implementation that was validated before
this final release naming pass. It is not a separate gameplay version.

================================================================
INSTALLATION
================================================================

Action Growth v1.0 requires a clean Final Fantasy V Advance (USA) ROM that is exactly 8,388,608 bytes with CRC32 7A24AB0C and SHA-256 55c5f8222759b556c562fc6f72f54ac01128e077e3dde25035be1158ff704374.

Apply FFV_GBA_Action_Growth_v10.ips with a standard IPS-compatible patcher. Do not apply it to a different region, revision, translation, or already modified ROM unless that specific combination has been independently verified. A new game is recommended for the intended progression curve.

Patched ROM CRC32: 08EDA71B
Patched ROM SHA-256: d6c77ac0b8ea3d491f037dbe8c886fa19d9bbeb82494d615493d969f9df7498d
IPS SHA-256: 8cdc95e2036e14e08d3af7acc66150120c407a320c9e3929c6b224e33a9d46a3

================================================================
CREDITS AND REFERENCES
================================================================

Project Design, ROM Hacking, Balance Direction, Planning and Testing: RetchERezzed
Inspired by: demgelphoenix

FF6Tools by everything8215 was used as a major Final Fantasy GBA ROM-structure and data-layout reference. Project: https://github.com/everything8215/ff6tools
Final Fantasy V Advance USA ROM definition: https://github.com/everything8215/ff6tools/blob/gh-pages/ff5/ff5u-gba.json

The Final Fantasy V reverse-engineering project by everything8215 was used as a structural reference for battle behavior, Level-based effects, Cover, Counter, multi-hit behavior, and other original-game mechanics. Project: https://github.com/everything8215/ff5
Battle program: https://github.com/everything8215/ff5/blob/main/src/battle/battle-main.asm
Battle RAM definitions: https://github.com/everything8215/ff5/blob/main/src/battle/battle_ram.inc

Final Fantasy V algorithm/stat references used during research include J.L. Tseng's Algorithms/Stats FAQ: https://gamefaqs.gamespot.com/gba/930369-final-fantasy-v-advance/faqs/30040
Final Fantasy V Advance Algorithm FAQ by redwolf and mog07: https://gamefaqs.gamespot.com/gba/930369-final-fantasy-v-advance/faqs/51713
KholdStareMud's Jobs Strategy Guide / character base-stat reference: https://gamefaqs.gamespot.com/gba/930369-final-fantasy-v-advance/faqs/49839

Runtime testing used mGBA 0.10.5. Project: https://github.com/mgba-emu/mgba
Website: https://mgba.io/

The ARM7TDMI/GBA build workflow used LLVM tools including Clang, LLD, and LLVM binary utilities. Project: https://llvm.org/
